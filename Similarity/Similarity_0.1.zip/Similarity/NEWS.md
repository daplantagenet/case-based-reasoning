# Similarity 0.1

+ New C++ matrix and vector ordering
+ New distances: Euclidian, Manhattan, Minkowski, and weighted L1 distance
+ New proximity matrix for a ranger RandomForest object
+ New depth matrix for a ranger RandomForest object
+ New terminal nodes for new observations for a ranger RandomForest object
+ New terminal node distance for a ranger RandomForest object
